# Introduction to Machine Learning Lab 01
Repo for Lab 01 of the course Introduction to Machine Learning 

How to use the script: 

### 1. classify the data set with the classifyData(...) function
### 2. choose a random prototype with the choosePrototype(...) function 
### 3. call doTraining(...) with the classified data, the function will simulate training and in the end plot the learning curve and the data points/classifications
### 4. RUN IT
