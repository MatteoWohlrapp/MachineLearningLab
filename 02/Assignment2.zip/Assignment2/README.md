# Introduction to Machine Learning Lab 02
Repo for Lab 02 of the course Introduction to Machine Learning 

How to use the script: 

### 1. RUN IT. Pdf's of the plots for errors and weights will be created and automatically saved to .pdf format.
